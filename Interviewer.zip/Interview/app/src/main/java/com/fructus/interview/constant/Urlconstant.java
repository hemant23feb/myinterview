package com.fructus.interview.constant;

public class Urlconstant
{
    public static String Url="http://delainetechnologies.com/haywood_drinks/app/";
}
